import 'package:flutter/material.dart';
import 'package:mentalink/src/Inicio.dart';
import 'package:mentalink/src/Servicios/Servicio.dart';
import 'package:mentalink/src/Views/Login/Login.dart';

class FinalizarRegistro extends StatefulWidget {
  final String nombre;
  final String apellido;
  final String correo;
  final String contrasena;

  const FinalizarRegistro({
    Key? key,
    required this.nombre,
    required this.apellido,
    required this.correo,
    required this.contrasena,
  }) : super(key: key);

  @override
  State<FinalizarRegistro> createState() => _FinalizarRegistroState();
}

class _FinalizarRegistroState extends State<FinalizarRegistro> {
  late DateTime _selectedDate;
  bool showCalendarIcon = true;
  String? _selectedSexo;

  List<String> genderOptions = ['Masculino', 'Femenino', 'Otro'];

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      locale: const Locale("es"),
    );
    if (picked != null && picked != _selectedDate)
      setState(() {
        _selectedDate = picked;
        showCalendarIcon = false;
      });
  }

  Future<void> _registro() async {
    dynamic registro = await Servicio().registrarUsuario({
      "nombre": widget.nombre,
      "apellido": widget.apellido,
      "correo": widget.correo,
      "contrasena": widget.contrasena,
      "genero": _selectedSexo ?? "",
      "fecha_nacimiento": "${_selectedDate.year}-${_selectedDate.month}-${_selectedDate.day}",
      "perfil_id": "5"
    });

    String status = registro['status'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(status == "success" ? "Éxito" : "Error"),
          content: status == "success"
              ? Text(registro['message'])
              : Text(registro['error']['text']),
          actions: <Widget>[
            ElevatedButton(
              child: Text('Aceptar'),
              onPressed: () {
                Navigator.of(context).pop();
                if (status == "success") {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => Login()),
                  );
                } else {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => Inicio()),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage("https://mentalink.tepuy21.com/assets/images/fondo.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  width: 260,
                  child: Image.network(
                    'https://mentalink.tepuy21.com/assets/images/logo-text.png',
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.7,
                  child: InputDecorator(
                    decoration: InputDecoration(
                      labelText: 'Género',
                      prefixIcon: Icon(Icons.person, color: Colors.grey),
                      contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.white),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      labelStyle: TextStyle(color: Colors.grey),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                    ),
                    child: TextButton(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          backgroundColor: Colors.white,
                          builder: (context) {
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              children: genderOptions.map((gender) {
                                return ListTile(
                                  title: Text(
                                    gender,
                                    style: TextStyle(color: Colors.black),
                                  ),
                                  onTap: () {
                                    setState(() {
                                      _selectedSexo = gender;
                                    });
                                    Navigator.pop(context);
                                  },
                                );
                              }).toList(),
                            );
                          },
                        );
                      },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _selectedSexo ??'Seleccione un género',
                          style: TextStyle(
                            color: _selectedSexo != null
                                ? Colors.white
                                : Color(0xFFa7a7a9),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: MediaQuery.of(context).size.width * 0.7,
                  child: TextField(
                    readOnly: true,
                    onTap: () => _selectDate(context),
                    decoration: InputDecoration(
                      hintText: 'Seleccione una fecha',
                      hintStyle: TextStyle(color: Color(0xFFa7a7a9)),
                      prefixIcon:
                          Icon(Icons.calendar_today, color: Colors.grey),
                      contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 2.0, color: Colors.white),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      labelStyle: TextStyle(color: Colors.grey),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                      ),
                    ),
                    controller: TextEditingController(
                      text: showCalendarIcon
                          ? ''
                          : '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(height: 20.0),
                Container(
                  margin: EdgeInsets.only(bottom: 15),
                  width: MediaQuery.of(context).size.width * 0.7,
                  child: ElevatedButton(
                    onPressed: _registro,
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      backgroundColor: Color.fromARGB(255, 0, 188, 207),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        side: BorderSide(width: 2.0, color: Colors.white),
                      ),
                      elevation: 5,
                    ),
                    child: Text(
                      'Finalizar Registro',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
