// ignore_for_file: use_key_in_widget_constructors, avoid_unnecessary_containers, prefer_const_constructors, prefer_const_literals_to_create_immutables, sized_box_for_whitespace, avoid_print, body_might_complete_normally_nullable, unused_local_variable

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:mentalink/src/Clases/appbar.dart';
import 'package:mentalink/src/Servicios/Servicio.dart';
import 'package:mentalink/src/Widgets/drawer.dart';
import 'package:mentalink/src/Widgets/footer.dart';
import 'package:mentalink/src/Widgets/formularioPreguntas.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {


  int paginaActual = 0;
  bool mostrarFormulario = false;

  List<dynamic> listaPsicologos = [];

  bool esFavorito = false;

  final ScrollController _scrollController = ScrollController();
  bool _isVisible = false;

  TextEditingController searchController = TextEditingController();
  List<dynamic> filtroPsicologos = [];

  List<dynamic> listaPsicologosEstados = [
    {
      "profesion":"Psicólogo"
    },
    {
      "profesion":"Psicólogo"
    },
    {
      "profesion":"Psicólogo"
    },
    {
      "profesion":"Psicólogo"
    },
    {
      "profesion":"Psicólogo"
    },
    {
      "profesion":"Psicólogo"
    },

  ];

  prueba(){

    print("hola victor");
  }

  /*@override
  void initState() {
    //prueba();
    Especialistas();
    super.initState();
    //_filtroPsicologos = List<Map<String, dynamic>>.from(listaPsicologos); 
  }

  Future<void> Especialistas() async {
    List<Map<String, dynamic>> listaEspecialistas = await Servicio().UsuariosEspecialistas();
    setState(() {
      listaPsicologos = listaEspecialistas;
      print(listaPsicologos);
    });
  }*/

  @override
  void initState() {
    super.initState();
    // Llama a la función para obtener los especialistas al inicio junto con la lista de filtrado
    obtenerEspecialistas();

    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection == ScrollDirection.reverse) {
        setState(() {
          _isVisible = true;
        });
      } else {
        setState(() {
          _isVisible = false;
        });
      }
    });

  }

  // Función para obtener los especialistas
  Future<void> obtenerEspecialistas() async {
    List<Map<String, dynamic>> listaEspecialistas = await Servicio().UsuariosEspecialistas();
    setState(() {
      listaPsicologos = listaEspecialistas;

      filtroPsicologos = List.from(listaPsicologos);
    });
  }


  void _onChanged(String value) {
    setState(() {
      filtroPsicologos = listaPsicologos.where((psicologo) {
        String nombreCompleto = "${psicologo['nombre']} ${psicologo['apellido']}";
        return nombreCompleto.toLowerCase().contains(value.toLowerCase());
      }).toList();
    });
  }

  /*void _onChanged(String value) {
    setState(() {
      filtroPsicologos = listaPsicologos.where((psicologo) {
        String nombreCompleto = "${psicologo['nombre']} ${psicologo['apellido']}";
        String? especialidad = psicologo['especialidad']?.toString();
        return nombreCompleto.toLowerCase().contains(value.toLowerCase()) &&
              (especialidad?.toLowerCase().contains(value.toLowerCase()) ?? false);
      }).toList();
    });
  }*/

  void scrollToTop() {
    _scrollController.animateTo(0, duration: Duration(seconds: 1), curve: Curves.easeInOut);
  }

  @override
  Widget build(BuildContext context) {

    //String nombrePsicologo = "";

    return mostrarFormulario ? formularioPreguntas(): 
    Scaffold(

      appBar: appbar().getAppbar(),

      body: SingleChildScrollView(
        controller: _scrollController,
        child: Container(
        
          padding: EdgeInsets.only(top: 30, bottom: 50, left: 20, right: 20),
          
          child: Column(
        
            children: [
        
        
              /**************************Estados Psicologos****************************************/
        
              Container(
        
                height: 80,
                //color: Colors.blue,
        
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  //itemCount: listaPsicologosEstados.length,
                  itemCount: listaPsicologos.length,
                  itemBuilder: (context,index){
        
                    //nombrePsicologo = listaPsicologosEstados[index]['profesion'];
                    String nombrePsicologo = listaPsicologos[index]['nombre'];
                    String fotoUrl = listaPsicologos[index]['foto'];
                    //print(fotoUrl);
        
                    return InkWell(
                      onTap: (){
                        print("hola");
                      },
                      child: Container(
        
                        child: Column(
                      
                          children: [
                      
                            /*Container(
                              width: 50,
                              height: 50,
                              margin: EdgeInsets.only(left: 5,right: 5,top: 5,bottom: 0),
                              //color: Colors.green,
                              decoration: BoxDecoration(
                                //color: Colors.red,
                                borderRadius: BorderRadius.circular(50), // Radio de 50 para lograr la forma redonda
                                image: DecorationImage(image: NetworkImage('https://mentalink.tepuy21.com/assets/images/ImagenPerfil.png'),fit: BoxFit.cover),
                                border: Border.all(
                                  color: Colors.green,
                                  width: 2,
                                ),
                              ),
                            ),*/
        
                            Container(
                              margin: EdgeInsets.only(left: 10),
                              width: 50,
                              height: 50,
                              child: fotoUrl.isNotEmpty
                                ? ClipOval(
                                    child: Image.network(
                                      "https://mentalink.tepuy21.com/api-mentalink/public/" + fotoUrl,
                                      fit: BoxFit.cover,
                                    ),
                                  )
                                : Icon(
                                    Icons.account_circle_rounded,
                                    color: Colors.grey,
                                    size: 50,
                                  ),
                            ),
                      
                            Container(child: Text(nombrePsicologo, style: TextStyle(fontWeight: FontWeight.bold),),)
                          ],
                        ),
                      )
                    );
                    
                  } 
                ),
        
              ),
        
              /**********************************Filtro*****************************************************************/
        
              Container(
                //color: Colors.amber,
                margin: EdgeInsets.only(top: 20),
                padding: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
        
                    /*Container(
                      width: 200,
                      height: 35,
        
                      child: TextFormField(
        
                        decoration: InputDecoration(
        
                          labelText: 'Buscar',
                          filled: false,
        
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Color.fromRGBO(10, 28, 92, 1)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Color.fromRGBO(72, 189, 199, 1)), // Cambiar el color del borde cuando está enfocado
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.red),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.red),
                          ),
        
                          suffixIcon: Container(
                            child: TextButton(
                              child: Icon(Icons.search),
                              onPressed: () {},
                            ),
                          ),
        
                        ),
        
                      ),
        
                    ),*/
        
                    Container(
        
                      width: 250,
                      height: 45,
        
                      child: TextFormField(
                        controller: searchController,
                        onChanged: _onChanged,
        
                        decoration: InputDecoration(
                          labelText: 'Buscar',
                          filled: false,
        
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color.fromRGBO(175, 175, 175, 1),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color.fromRGBO(72, 189, 199, 1),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.red),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.red),
                          ),
        
                          suffixIcon: Container(
                            child: TextButton(
                              child: Icon(
                                Icons.search,
                                color: Color.fromRGBO(175, 175, 175, 1),
                              ),
                              onPressed: () {},
                            ),
                          ),
        
                        ),
        
                      ),
        
                    ),
        
        
                    Container(
                      child: TextButton(
                        onPressed: () {
                        
                        },
                        child: Icon(Icons.filter_alt_outlined,
                        color: Color.fromRGBO(172, 172, 172, 1.0),
                        size: 32.0,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
        
              /**********************************Lista Psicologos*****************************************************************/
        
              /*Expanded(
                child: Container(
                  margin: EdgeInsets.only(top: 20),
                  child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: listaPsicologos.length,
                    itemBuilder: (context, index) {
                      String nombrePsicologo = listaPsicologos[index]['nombre'];
                      String apellido = listaPsicologos[index]['apellido'];
        
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).pushNamed("/menuEspecialistas");
                        },
                        child: Container(
                          height: 130,
                          margin: EdgeInsets.only(top: 10),
                          child: Card(
                            color: Colors.white,
                            elevation: 4.0,
                            child: Padding(
                              padding: EdgeInsets.all(10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 50,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            color: Colors.blue,
                                            borderRadius: BorderRadius.circular(50),
                                            image: DecorationImage(image: NetworkImage('https://mentalink.tepuy21.com/assets/images/ImagenPerfil.png'),fit: BoxFit.cover),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 10),
                                          padding: EdgeInsets.all(5),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "${nombrePsicologo.toUpperCase()[0]}${nombrePsicologo.substring(1)} ${apellido.toUpperCase()[0]}${apellido.substring(1)}",
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Text(
                                                "Psicólogo",
                                                style: TextStyle(fontWeight: FontWeight.w200),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(right: 5),
                                          decoration: BoxDecoration(
                                            color: Colors.blue,
                                            borderRadius: BorderRadius.circular(50),
                                          ),
                                          child: TextButton(
                                            onPressed: () {},
                                            style: ButtonStyle(elevation: MaterialStateProperty.all(10.0)),
                                            child: Icon(Icons.star,color: Colors.white,),
                                          ),
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                            color: Colors.blue,
                                            borderRadius: BorderRadius.circular(50),
                                          ),
                                          child: TextButton(
                                            onPressed: () {},
                                            style: ButtonStyle(elevation: MaterialStateProperty.all(10.0)),
                                            child: Icon(Icons.search, color: Colors.white,),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              )*/
        
              /*Expanded(
                child: Container(
                  margin: EdgeInsets.only(top: 20),
                  child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    //itemCount: listaPsicologos.length,
                    itemCount: filtroPsicologos.length,
                    itemBuilder: (context, index) {
                      
                      /*String nombrePsicologo = listaPsicologos[index]['nombre'];
                      String apellido = listaPsicologos[index]['apellido'];
                      String fotoUrl = listaPsicologos[index]['foto'];
                      bool isSelected = listaPsicologos[index]['isSelected'] ?? false; // está estatico luego hay que cambiar por el favorito de la tabla */
        
                      String nombrePsicologo =  filtroPsicologos[index]['nombre'];
                      String apellido =  filtroPsicologos[index]['apellido'];
                      String fotoUrl =  filtroPsicologos[index]['foto'];
                      bool isSelected =  filtroPsicologos[index]['isSelected'] ?? false; 
        
                      return InkWell(
                        onTap: () {
                          setState(() {
                            filtroPsicologos[index]['isSelected'] = !isSelected;
                            Navigator.of(context).pushNamed("/menuEspecialistas");
                          });
                        },
                        child: Container(
                          height: 130,
                          margin: EdgeInsets.only(top: 10),
                          child: Card(
                            //color: isSelected ? Color.fromRGBO(221, 219, 219, 0) : Colors.white,
                            elevation: 4.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(
                                color: isSelected ? Color.fromRGBO(72, 189, 199, 1) : Colors.transparent,
                                width: 2.0,
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 60,
                                          height: 60,
                                          child: fotoUrl.isNotEmpty
                                              ? ClipOval(
                                                  child: Image.network(
                                                    fotoUrl,
                                                    fit: BoxFit.cover,
                                                  ),
                                                )
                                              : Icon(Icons.account_circle_rounded, color: Colors.grey, size: 60),
                                        ),
                                        SizedBox(width: 10),
                                        Container(
                                          padding: EdgeInsets.all(5),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "${nombrePsicologo.toUpperCase()} ${apellido.toUpperCase()}",
                                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                              ),
                                              Text(
                                                "Psicólogo",
                                                style: TextStyle(fontWeight: FontWeight.w200, fontSize: 14),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(right: 2),
                                          child: TextButton(
                                            onPressed: () {
                                              setState(() {
                                                filtroPsicologos[index]['isSelected'] = !isSelected;
                                              });
                                            },
                                            style: ButtonStyle(
                                              elevation: MaterialStateProperty.all(10.0),
                                              minimumSize: MaterialStateProperty.all(Size(40, 40)),
                                              padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                                            ),
                                            child: Icon(
                                              isSelected ? Icons.star : Icons.star_border,
                                              color: isSelected ? Color.fromRGBO(72, 189, 199, 1) : Color.fromRGBO(72, 189, 199, 1),
                                              size: 30,
                                            ),
                                          ),
                                        ),
                                        TextButton(
                                          onPressed: () {},
                                          style: ButtonStyle(
                                            elevation: MaterialStateProperty.all(10.0),
                                            minimumSize: MaterialStateProperty.all(Size(40, 40)),
                                            padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                                          ),
                                          child: Icon(Icons.search, color: Color.fromRGBO(72, 189, 199, 1), size: 30),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              )*/
        
                  Container(
                    margin: EdgeInsets.only(top: 20),
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: filtroPsicologos.length,
                      itemBuilder: (context, index) {
                        String nombrePsicologo = filtroPsicologos[index]['nombre'];
                        String apellido = filtroPsicologos[index]['apellido'];
                        String fotoUrl = filtroPsicologos[index]['foto'];
                        String especialidad = filtroPsicologos[index]['especialidad'] ?? "Psicólogo";
                        //bool isSelected =  filtroPsicologos[index]['favorito'] ?? false; 

                        String favorito = filtroPsicologos[index]['favorito'];
                        bool isSelected = favorito == "true" ? true : false;

                      return InkWell(
                        onTap: () {
                          setState(() {
                            //filtroPsicologos[index]['isSelected'] = !isSelected;
                            
                            Map<String, dynamic> psicologoSeleccionado = {
                              'id': filtroPsicologos[index]['usuario_id'],
                              'nombre': filtroPsicologos[index]['nombre'],
                              'apellido': filtroPsicologos[index]['apellido'],
                              'foto': filtroPsicologos[index]['foto'],
                            };
                            Navigator.of(context).pushNamed("/menuEspecialistas", arguments: psicologoSeleccionado);
                          });
                        },
                          child: Container(
                            height: 130,
                            margin: EdgeInsets.only(top: 10),
                            child: Card(
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(
                                  color: isSelected ? Color.fromRGBO(72, 189, 199, 1) : Colors.transparent,
                                  width: 2.0,
                                ),
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 60,
                                            height: 60,
                                            child: fotoUrl.isNotEmpty
                                                ? ClipOval(
                                                    child: Image.network(
                                                      "https://mentalink.tepuy21.com/api-mentalink/public/" + fotoUrl,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  )
                                                : Icon(
                                                    Icons.account_circle_rounded,
                                                    color: Colors.grey,
                                                    size: 60,
                                                  ),
                                          ),
                                          SizedBox(width: 10),
                                          Container(
                                            padding: EdgeInsets.all(5),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "${nombrePsicologo.toUpperCase()} ${apellido.toUpperCase()}",
                                                  style: TextStyle(fontWeight: FontWeight.bold),
                                                ),
                                                Text(
                                                  especialidad,
                                                  style: TextStyle(fontWeight: FontWeight.w200),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.only(right: 2),
                                            child: TextButton(
                                              
                                              onPressed: () async {
                                                // Llama a la función para marcar/desmarcar usuario como favorito
                                                await Servicio().marcarUsuario(filtroPsicologos[index]['usuario_id']);

                                                // Actualiza el estado local después de la respuesta del servicio
                                                setState(() {
                                                  filtroPsicologos[index]['favorito'] = isSelected ? "false" : "true";
                                                });
                                              },

                                              style: ButtonStyle(
                                                elevation: MaterialStateProperty.all(10.0),
                                                minimumSize: MaterialStateProperty.all(Size(40, 40)),
                                                padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                                              ),
                                              child: Icon(
                                                isSelected ? Icons.star : Icons.star_border,
                                                color: isSelected ? Color.fromRGBO(72, 189, 199, 1) : Color.fromRGBO(72, 189, 199, 1),
                                                size: 30,
                                              ),
                                            ),
                                          ),
                                          TextButton(
                                            onPressed: () {},
                                            style: ButtonStyle(
                                              elevation: MaterialStateProperty.all(10.0),
                                              minimumSize: MaterialStateProperty.all(Size(40, 40)),
                                              padding: MaterialStateProperty.all(EdgeInsets.all(10)),
                                            ),
                                            child: Icon(
                                              Icons.search,
                                              color: Color.fromRGBO(72, 189, 199, 1),
                                              size: 30,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  )
        
              
            ],
          ),
        ),
      ),
      floatingActionButton: _isVisible
        ? FloatingActionButton(
          onPressed: () {
            scrollToTop();
          },
          child: Icon(Icons.arrow_upward),
        )
        : null,

      drawer: NowDrawer(currentPage: 'Home',),
      bottomNavigationBar: Footer(),
    );
  }
}
