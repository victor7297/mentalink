import 'package:flutter/material.dart';
import 'package:mentalink/src/Clases/appbar.dart';
import 'package:mentalink/src/Widgets/drawer.dart';

class Citas extends StatelessWidget {
  const Citas({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: appbar().getAppbar(),

      drawer: NowDrawer(currentPage: 'Citas',),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildIcon(Icons.check_circle, 'Confirmada', context),
                _buildIcon(Icons.pending, 'Pendiente', context),
                _buildIcon(Icons.cancel, 'Cancelada', context),
              ],
            ),
          ),
          Expanded(
            child: PageView(
              children: [
                _buildSection('confirmada', context),
                _buildSection('pendiente', context),
                _buildSection('cancelada', context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon(IconData icon, String label, BuildContext context) {
    return Column(
      children: [
        Icon(
          icon,
          color: Color.fromARGB(255, 0, 188, 207),
          size: 32,
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            color: Color.fromRGBO(9, 25, 87, 1.0),
          ),
        ),
      ],
    );
  }

  Widget _buildSection(String status, BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nombre',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromRGBO(9, 25, 87, 1.0),
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(
                        Icons.person,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Nombre: psicologo digo yo',
                        style: TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Icon(
                        Icons.calendar_today,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Fecha: DD/MM/AAAA',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Hora: HH:MM',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Icon(
                        Icons.mail,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Correo: correo@e.com',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  // Mostrar botones de acción solo para citas pendientes
                  if (status == 'pendiente')
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {},
                          child: Text('Confirmar'),
                        ),
                        ElevatedButton(
                          onPressed: () {},
                          child: Text('Cancelar'),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
