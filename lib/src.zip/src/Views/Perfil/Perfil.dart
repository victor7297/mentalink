import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mentalink/src/Clases/appbarPerfil.dart';
import 'package:mentalink/src/Servicios/Servicio.dart';
import 'package:mentalink/src/Widgets/drawer.dart';
import 'package:shared_preferences/shared_preferences.dart';


class PerfilEspecialista extends StatefulWidget {
  const PerfilEspecialista({super.key});

  @override
  State<PerfilEspecialista> createState() => _PerfilEspecialistaState();
}

class _PerfilEspecialistaState extends State<PerfilEspecialista> {

  /*List<String> imgArray = [
    "https://images.unsplash.com/photo-1487376480913-24046456a727?fit=crop&w=240&q=80",
    "https://images.unsplash.com/photo-1487376480913-24046456a727?fit=crop&w=240&q=80",
    "https://images.unsplash.com/photo-1487376480913-24046456a727?fit=crop&w=240&q=80",
  ];*/

  String token = "";
  String usuarioId = "";
  String tipoUsuario = "";

  @override
  void initState() {
    super.initState();
    _recuperarDatos();
  }

  /*Future<void> _recuperarDatos() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      token = prefs.getString('token') ?? "No se encontró el token";
      usuarioId = prefs.getString('usuario_id') ?? "No se encontró el usuario ID";
      tipoUsuario = prefs.getString('tipo_usuario') ?? "No se encontró el tipo de usuario";
    });
    
    // Imprimir en consola
    print("Token: $token");
    print("Usuario ID: $usuarioId");
    print("Tipo de usuario: $tipoUsuario");
  }*/

  Map<String, dynamic> usuarioData = {};

  Future<void> _recuperarDatos() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String usuarioId = prefs.getString('usuario_id') ?? "";

    // Llamar al servicio para obtener el usuario especialista
    Map<String, dynamic> userData = await Servicio().obtenerInformacionUsuarioEspecialista(int.parse(usuarioId));

    setState(() {
      usuarioData = userData;
    });
  }

  String? rutaImagenSeleccionada;

// Método para seleccionar una imagen
  Future<void> _seleccionarImagen() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        rutaImagenSeleccionada = pickedFile.path;
      });
    } else {
      print('No se seleccionó ninguna imagen.');
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      //extendBodyBehindAppBar: true,
      appBar: AppBarPerfil().getAppbar(),

      drawer: NowDrawer(currentPage: 'Perfil',),

      body: SingleChildScrollView(

        child: Stack(

          children: [

            Container(
              height: MediaQuery.of(context).size.height * 0.56,
              child: Stack(
                children: [
                  // Imagen del servicio
                  if (usuarioData['foto'] != null && usuarioData['foto'] != "")
                    Image.network(
                      "https://mentalink.tepuy21.com/api-mentalink/public/"+usuarioData['foto'],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    )
                  else
                    // Si no hay una imagen del servicio, muestra una imagen predeterminada
                    Image.network(
                      'https://mentalink.tepuy21.com/assets/images/icono-perfil-usuario.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    ),
                  // Mostrar la imagen seleccionada si hay una
                  if (rutaImagenSeleccionada != null)
                    Positioned.fill(
                      child: Image.file(
                        File(rutaImagenSeleccionada!),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
              ),
            ),


            Container(
              height: MediaQuery.of(context).size.height * 0.56,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.center,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0),
                    Colors.black.withOpacity(0.9),
                  ]
                )
              ),
            ),

            Container(

              margin: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * 0.40,
              ),

              padding: EdgeInsets.symmetric(horizontal: 28),

              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [

                Padding(
                  padding: const EdgeInsets.only(bottom: 4.0),
                  child: Row(
                    children: [
                      Text(
                        "${usuarioData['nombre']} ${usuarioData['apellido']}",
                        style: TextStyle(fontSize: 28, color: Colors.white),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 5),
                        child: IconButton(
                          icon: Icon(Icons.camera_alt),
                          onPressed: () {
                            _seleccionarImagen();
                          },
                          color: Color.fromRGBO(254, 36, 114, 1.0),
                        ),
                      ),
                    ],
                  ),
                ),


                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 6),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Color.fromRGBO(254, 36, 114, 1.0)
                              ),
                              child: Text(
                                usuarioData['especialidad'] ?? 'Psicólogo',
                                style: TextStyle(color: Colors.white, fontSize: 16),
                              ),
                            ),
                          ),
                          /*Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Text(
                              "estrellias",
                              style: TextStyle(color: Colors.white, fontSize: 16)
                            ),
                          ),*/
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 4.0),
                                child: Text(
                                  "4.8",
                                  style: TextStyle(color: Color.fromRGBO(255, 152, 0, 1.0), fontSize: 16)
                                ),
                              ),
                              Icon(Icons.star_border, color: Color.fromRGBO(255, 152, 0, 1.0), size: 20)
                            ],
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Icon(Icons.pin_drop, color: Color.fromRGBO(151, 151, 151, 1.0)),
                          ),
                          Text(
                            "Mentalink, CA",
                            style: TextStyle(color: Color.fromRGBO(151, 151, 151, 1.0))
                          )
                        ],
                      )
                    ],
                  )
                ],
              ),
            ),

            Container(
              margin: EdgeInsets.only(top: 20),

              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 8,
                        blurRadius: 10,
                        offset: Offset(0, 0)
                      )
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(13.0),
                      topRight: Radius.circular(13.0),
                    )
                  ),
                  margin: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * 0.50,
                  ),
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 12.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                Text("36", style: TextStyle(fontWeight: FontWeight.w600)),
                                SizedBox(height: 6),
                                Text("Pacientes", style: TextStyle(color: Color.fromRGBO(151, 151, 151, 1.0)))
                              ],
                            ),
                            Column(
                              children: [
                                Text("5", style: TextStyle(fontWeight: FontWeight.w600)),
                                SizedBox(height: 6),
                                Text("Favoritos", style: TextStyle(color: Color.fromRGBO(151, 151, 151, 1.0)))
                              ],
                            ),
                            Column(
                              children: [
                                Text("2", style: TextStyle(fontWeight: FontWeight.w600)),
                                SizedBox(height: 6),
                                Text("Mensajes", style: TextStyle(color: Color.fromRGBO(151, 151, 151, 1.0)))
                              ],
                            ),
                          ],
                        ),
                        Column(
                          children: [

                            Container(
                              margin: EdgeInsets.only(top: 16, bottom: 10),

                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Sobre Mi",
                                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.0),
                                  ),
                                  /*Text(
                                    "Ver",
                                    style: TextStyle(color: Color.fromRGBO(156, 38, 176, 1.0), fontSize: 12.0),
                                  ),*/
                                ],
                              ),
                            ),

                            Container(

                              margin: EdgeInsets.only(bottom: 10),

                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    usuarioData['biografia'] ?? '...',
                                    style: TextStyle(color: Color.fromRGBO(151, 151, 151, 1.0)),
                                  ),
                                ],
                              ),
                            ),

                            Column(
                          children: [

                          Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pushNamed(context, '/detallesCuentaEspecialista');
                                },
                                child: Container(
                                  padding: EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 2,
                                        blurRadius: 5,
                                        offset: Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.account_circle, size: 30),
                                          SizedBox(width: 10),
                                          Text(
                                            'Detalles de la cuenta',
                                            style: TextStyle(fontSize: 18),
                                          ),
                                        ],
                                      ),
                                      Icon(Icons.arrow_forward_ios),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              //padding: EdgeInsets.symmetric(horizontal: 10),
                              padding: EdgeInsets.only(left: 10,right: 10, bottom: 40),
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pushNamed(context, '/CambiarC');
                                },
                                child: Container(
                                  padding: EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 2,
                                        blurRadius: 5,
                                        offset: Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.lock, size: 30),
                                          SizedBox(width: 10),
                                          Text(
                                            'Cambiar Contraseña',
                                            style: TextStyle(fontSize: 18),
                                          ),
                                        ],
                                      ),
                                      Icon(Icons.arrow_forward_ios),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            
                          ],
                        )

                            /*SizedBox(
                              height: 250,
                              child: GridView.count(
                                primary: false,
                                padding: EdgeInsets.symmetric(vertical: 12.0),
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                crossAxisCount: 3,
                                children: imgArray
                                    .map(
                                      (item) => Container(
                                        height: 100,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(Radius.circular(4.0)),
                                          image: DecorationImage(
                                            image: NetworkImage(item),
                                            fit: BoxFit.cover
                                          )
                                        )
                                      )
                                    )
                                    .toList()
                              )
                            )*/
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),

            )
          ],
        ),
      )
    );
  }
}