// ignore_for_file: avoid_print, unused_import, non_constant_identifier_names, prefer_interpolation_to_compose_strings

import 'dart:io';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:mentalink/src/Views/Psicologos/agendarCita.dart';

class Servicio {

  String ruta = "https://mentalink.tepuy21.com/api-mentalink/public/";

  Future<Map<String, dynamic>> registrarUsuario(

    Map<String, dynamic> data) async {
    var url = Uri.parse(ruta + "usuarios");
    var response = await http.post(url, body: data);
    var respuestaJson = jsonDecode(response.body);

    return respuestaJson;
  }

  Future<dynamic> validarLogin(data) async {

    var url = Uri.parse(ruta + "login");
    var response = await http.post(url, body: data);
    var respuestaJson = jsonDecode(response.body);

    return respuestaJson;
  }

  /*Future<List<Map<String, dynamic>>> UsuariosEspecialistas() async {
    var url = Uri.parse(ruta + "/usuarios-especialistas-app");

      var response = await http.get(url);
      
      if (response.statusCode == 200) {

        List<dynamic> especislistasJson = jsonDecode(response.body);

        List<Map<String, dynamic>> especialistas = List<Map<String, dynamic>>.from(especislistasJson);

        return especialistas;

      } else {

        throw Exception('${response.statusCode}');
        
      }
  }*/
  

  Future<List<Map<String, dynamic>>> UsuariosEspecialistas() async {
    var url = Uri.parse(ruta + "usuarios-especialistas");
    var response = await http.get(url);

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(jsonDecode(response.body));
    } else {
      throw Exception('${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> obtenerInformacionUsuarioEspecialista(int id) async {
    var url = Uri.parse(ruta + "usuarios-especialistas/$id");
    var response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> obtenerUsuario(int id) async {
    var url = Uri.parse(ruta + "usuarios/$id");
    var response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> angendarCita(Map<String, dynamic> data) async {
    var url = Uri.parse(ruta + "agendar-cita");
    var response = await http.post(url, body: data);
    var respuestaJson = jsonDecode(response.body);

    return respuestaJson;
  }

  Future<Map<String, dynamic>> marcarUsuario(String usuarioId) async {
    var url = Uri.parse(ruta + "/marcar-usuario/$usuarioId");
    var response = await http.post(url);
    var respuestaJson = jsonDecode(response.body);
    return respuestaJson;
  }


  /*Future<Map<String, dynamic>> actualizarFotoPerfil(int usuarioId, File fotoFile) async {
    var url = Uri.parse(ruta + "usuarios/$usuarioId/foto_perfil");
    
    var request = http.MultipartRequest('POST', url);
    request.files.add(await http.MultipartFile.fromPath('foto', fotoFile.path));

    var response = await request.send();
    var responseBody = await response.stream.bytesToString();
    var respuestaJson = jsonDecode(responseBody);

    if (response.statusCode == 200) {
      return respuestaJson;
    } else {
      throw Exception('${response.statusCode}');
    }
  }*/

  Future<void> actualizarFotoPerfil(File fotoFile, int usuarioId) async {
    var url = Uri.parse(ruta + "usuarios/$usuarioId/foto_perfil");

    var request = http.MultipartRequest('POST', url);
    var multipartFile = http.MultipartFile(
      'foto',
      fotoFile.readAsBytes().asStream(),
      fotoFile.lengthSync(),
      filename: fotoFile.path.split('/').last,
    );
    request.files.add(multipartFile);
    request.headers['Accept'] = 'image.webp';

    var response = await request.send();
    var responseData = await response.stream.bytesToString();
    var respuestaJson = jsonDecode(responseData);

    if (response.statusCode == 200) {
      return respuestaJson;
    } else {
      throw Exception('${response.statusCode}');
    }
  }


  Future<dynamic> prueba() async {

    var url = Uri.parse(ruta + "usuarios");
    var response = await http.get(url);
    var respuestaJson = jsonDecode(response.body);
    

    if(response.statusCode == 200){

      var data = {
        "status": response.statusCode
      };

      return data;

    }
    else{
      var data = {
        "status": response.statusCode
      };

      return data;
    }

  }

    
}
