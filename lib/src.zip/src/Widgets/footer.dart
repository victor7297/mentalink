import 'package:flutter/material.dart';

class Footer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 65.0,
      child: BottomAppBar(
        color: Color.fromRGBO(9, 25, 87, 1.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            /*Expanded(
              child: Column(
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.home, size: 30, color: Colors.white),
                    onPressed: () {
                      Navigator.of(context).pushNamed("/PantallaInicio");
                    },
                  ),
                ],
              ),
            ),*/
            Expanded(
              child: Column(
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.event, size: 25, color: Colors.white),
                    onPressed: () {
                      Navigator.of(context).pushNamed("/PantallaCitas");
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.center_focus_weak_outlined, size: 25, color: Colors.white),
                    onPressed: () {
                      Navigator.of(context).pushNamed("/");
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.account_circle_outlined, size: 25, color: Colors.white),
                    onPressed: () {
                      Navigator.of(context).pushNamed("/");
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
