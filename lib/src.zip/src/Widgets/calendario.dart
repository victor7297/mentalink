import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:intl/intl.dart';
import 'package:mentalink/src/Servicios/Servicio.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:googleapis/calendar/v3.dart' as calendar;
import 'package:googleapis_auth/googleapis_auth.dart';


class CustomTimePicker extends StatefulWidget {
  final TimeOfDay initialTime;
  final void Function(TimeOfDay) onTimeSelected;

  const CustomTimePicker({
    required this.initialTime,
    required this.onTimeSelected,
    Key? key,
  }) : super(key: key);

  @override
  _CustomTimePickerState createState() => _CustomTimePickerState();
}

class _CustomTimePickerState extends State<CustomTimePicker> {
  late TimeOfDay _selectedTime;

  @override
  void initState() {
    super.initState();
    _selectedTime = widget.initialTime;
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoTheme(
      data: CupertinoThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: Colors.white,
      ),
      //height: 200,
      //agregar container con un heihg de 200
      child: Container(
        height: MediaQuery.of(context).size.width * 0.6,
        child: Column(
          children: [
            SizedBox(
              height: 160,
              child: CupertinoDatePicker(
                mode: CupertinoDatePickerMode.time,
                initialDateTime: DateTime(2000, 1, 1, _selectedTime.hour, _selectedTime.minute),
                onDateTimeChanged: (DateTime dateTime) {
                  setState(() {
                    _selectedTime = TimeOfDay.fromDateTime(dateTime);
                  });
                },
              ),
            ),
            TextButton(
              onPressed: () {
                widget.onTimeSelected(_selectedTime);
              },
              child: Text(
                'Seleccionar',
                style: TextStyle(color: Colors.blue),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Calendario extends StatefulWidget {
  final String? psicologoId;

  Calendario(this.psicologoId, {Key? key}) : super(key: key);

  @override
  _CalendarioState createState() => _CalendarioState();
}

class _CalendarioState extends State<Calendario> {

  final scopes = [calendar.CalendarApi.calendarScope];
  final credentials = ServiceAccountCredentials.fromJson({
    "type": "service_account",
    "project_id": "mentalink",
    "private_key_id": "267b2a29fd8d4e0645b0c5a21f995f8212a8f5b3",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDiokZe64bnOaTy\n78RfmoWXxKqAe4QnAl3rZ6H2RTF/NL9Vp1kQ6FrKNDmalyvw5wZQs4w1NqoXy7h0\nua2XSN6hhfhC3p9vYBz/iNpIO894MkMrKKMSc67dricfpupBVUZQerRIS38wwLVq\nEWlx0/Uj8gqJKoe2/UJyGfrJLuHfUt6blH7OibB1lA8XJ+mLWn1+93H5CoOLXdUy\nQuhkeQ3cSfdykSvxbiVo7eUoeoDBHkmJ1RiA7EZjiXGQII2UHJvKjKEZM6EwiB7Q\nrU2AUHv3UtmK7nMi8Cu4Q6Q6ejLRQqn3jCbMTVxB3smwej9IzVPhhIBoPt3lxopI\nFNFYsMghAgMBAAECggEAAXvbVuzsV8W3GIHCM6JfnGAvge1XxBNIzvfWpeCLQ9Wy\nKKr9PeDY5/4tCrUm1r+FzqVKS6E6vl1OrRxNGxKL+0XqW50OXAHmrAlMQpD6WViy\nO2KwpKLeGCSh1sbL6FcZAYG4KJ6ulmtglLFIqIk2ekCFWfi4ZZXlZ46s0hXiPokk\nIAL635yZvdT/0DP5nDDi0fI+NH3VxI4+Tr5UD7yB4hskl9opixDUschWCvE27Dfn\n9v5NUP9TzP2L0RLXKKvUhyzzbu73zFXRlCBr3TMMGdQBhclAX44xT4OtYxEELvoo\n6dYV8yiG7aAdCKr/zey/2Ak2XKIR8gbgljjCuzIDUQKBgQDyUPh/JtcrD7eNbl6P\n56zueVB/AmH1CmJWCVzFIldn3/MaN3Ri5qiINzeGpokP5IedFhcFm51alX5IHA/m\nk7dDpJhg+UhVW/lEgCsSuqGoYWzx5g2J3wbWXkBC/EiQVPI+9eJkh+00oshVaPjL\n+5dEl1duOaGqFEJNxd2zW5JMWQKBgQDvbpexJQ2LJ941qxm1BazbJD20U9tDi0R3\nKbZ5h+Uelae8kZ6DZlQzRqzgtAFU9b+uc3vc6/v2TgK5tuRp10kI/j3eP5lST8o3\n3g6XE7G62bMuhHKj38n9xgI+128WLyUttL/P8XWIIh7ca65QGLnm2PvC+TUYUObC\nlv05KUXBCQKBgGOjL8r46ZjnSY56R5/cn5sffx36mNTthCnkh6T3zgEEcS3ih5Tz\nS3FXYxmW+Nz0F19cafMAXd+VgOudvlwNeVnzIEUfu8J9oy2rlgqJe1eFWArPkdmT\nP3h+IOZqXlwa0dFZwdGcosj19nJIS6V0umqV4HmOcQ9CbVEVf2f0y19hAoGATXZ3\nR02YkyPj5XMkzwc2BHQ2LmhO8QxWq0LokWsg+oMqkHyATzzFEw3TkqNKJwWW7UbZ\nlQEYNHjKsvDz9zY6n9k5hPUIkrPT1b1W9RPfFXenW+5n9JLLk/oC8ffbLc809ROc\nVxdkkhWP7Ho+HBXT11buJQdhYSuTbPNSm7K5qZkCgYAxpz2sdXHCcZ2EwJ5yj7sN\n/b/aGT4D/h4FV7LXhKcFpZG2wpkaq4Mi19NTtVeA4LxYxH5x6+/YHJrhumNVDLyk\np6dpGTql9dzign9nSLwShhvZSY1TwVPLyqECAqn5UfC5pT1Jty1zpBNsjOnHEFeM\nFyDE6o7ZOU/enC5KJrlLaw==\n-----END PRIVATE KEY-----\n",
    "client_email": "mentalink@mentalink.iam.gserviceaccount.com",
    "client_id": "106763373788757272360",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/mentalink%40mentalink.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  });

  late final String? idPsicologo;

  late AuthClient cliente;
  late String? accessToken;

    @override
    void initState() {
      super.initState();
      idPsicologo = widget.psicologoId;
      _initGoogleApiClient();
    }

    void _initGoogleApiClient() async {
      cliente = await clientViaServiceAccount(credentials, scopes);

      var accessToken = cliente.credentials.accessToken.data;
    }

  

    List<DateTime> coloredDates = [];
    DateTime seleccionarFecha = DateTime.now();
    TimeOfDay hora = TimeOfDay.now();
    TextEditingController _descriptionController = TextEditingController();
    TextEditingController linkController = TextEditingController();
    bool presencial = false;
    bool remota = false;

    /*Future<void> _agendarCita() async {

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String usuarioId = prefs.getString('usuario_id') ?? "";

    if (_descriptionController.text.isEmpty ||
        seleccionarFecha == null ||
        hora == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '¡Complete Todos Los Campos!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Color.fromARGB(255, 0, 188, 207),
        ),
      );
      return;
    }

    // Determinar el tipo de cita
    String tipoCita;
    if (presencial) {
      tipoCita = 'presencial';
    } else if (remota) {
      tipoCita = 'remota';
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Seleccione al menos un tipo de cita (presencial o remota)',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Color.fromARGB(255, 0, 188, 207),
        ),
      );
      return;
    }

    // Preparar datos dependiendo del tipo de cita
    Map<String, dynamic> data = {
      'psicologo_id': idPsicologo,
      'paciente_id': usuarioId,
      'fecha_hora': DateTime(
        seleccionarFecha.year,
        seleccionarFecha.month,
        seleccionarFecha.day,
        hora.hour,
        hora.minute,
      ).toString(),
      'descripcion': _descriptionController.text,
      'tipo_cita': tipoCita,
    };

    if (tipoCita == 'remota') {
      // Incluir el campo link si es remota
      data['link'] = linkController; // Asumiendo que tienes un TextEditingController para el campo link
    }

    final response = await Servicio().angendarCita(data);

    if (response['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.green,
          content: Text(
            response['message'],
            textAlign: TextAlign.center,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text(
            response['message'],
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
  }*/

  Future<void> _agendarCita() async {

  SharedPreferences prefs = await SharedPreferences.getInstance();
  String usuarioId = prefs.getString('usuario_id') ?? "";
  

  if (_descriptionController.text.isEmpty ||
      seleccionarFecha == null ||
      hora == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '¡Complete Todos Los Campos!',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color.fromARGB(255, 0, 188, 207),
      ),
    );
    return;
  }

  // Determinar el tipo de cita
  String tipoCita;
  if (presencial) {
    tipoCita = 'presencial';
  } else if (remota) {
    tipoCita = 'remota';
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Seleccione al menos un tipo de cita (presencial o remota)',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color.fromARGB(255, 0, 188, 207),
      ),
    );
    return;
  }

  // Preparar datos dependiendo del tipo de cita
  Map<String, dynamic> data = {
    'psicologo_id': idPsicologo,
    'paciente_id': usuarioId,
    'fecha_hora': DateTime(
      seleccionarFecha.year,
      seleccionarFecha.month,
      seleccionarFecha.day,
      hora.hour,
      hora.minute,
    ).toString(),
    'descripcion': _descriptionController.text,
    'tipo_cita': tipoCita,
  };

  try {
    // Crear objeto de evento para Google Calendar
    var event = calendar.Event();
    event.summary = 'Reunión de equipo';
    event.start = calendar.EventDateTime(dateTime: DateTime.utc(2024, 6, 28, 7, 0, 0));
    event.end = calendar.EventDateTime(dateTime: DateTime.utc(2024, 6, 28, 8, 0, 0));

    // Configurar datos de conferencia para Google Meet
    if (tipoCita == 'remota') {
      event.conferenceData = calendar.ConferenceData(
        createRequest: calendar.CreateConferenceRequest(
          requestId: 'unique-request-id',
          conferenceSolutionKey: calendar.ConferenceSolutionKey(
            type: 'hangoutsMeet'
          )
        )
      );
    }
    // Insertar evento en Google Calendar
    var calendarApi = calendar.CalendarApi(cliente);

    print(cliente.credentials.accessToken.data);

    var result = await calendarApi.events.insert(
      event, 'primary',
    );

    // Verificar si hay un enlace de Google Meet disponible
    var meetLink = result.hangoutLink;
    // Actualizar los datos para incluir el enlace, manejando el caso de que meetLink sea null
    data['link'] = meetLink?.toString() ?? '';

    // Guardar la cita
    final response = await Servicio().angendarCita(data);

    if (response['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.green,
          content: Text(
            response['message'],
            textAlign: TextAlign.center,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text(
            response['message'],
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
  } catch (e) {
    print('Error: $e');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(
          'Error al crear la reunión remota.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

}


  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 10,
          margin: EdgeInsets.only(left: 20, right: 20, top: 5, bottom: 10),
          child: Container(
            padding: EdgeInsets.all(5),
            child: Theme(
              data: Theme.of(context).copyWith(
                colorScheme: Theme.of(context).colorScheme.copyWith(
                  secondary: Theme.of(context).primaryColor,
                ),
              ),
              child: _buildDatePicker(),
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.only(left: 25, bottom: 10),
          width: MediaQuery.of(context).size.width * 0.5,
          child: ElevatedButton(
            onPressed: () {
              _showCustomTimePicker(context);
            },
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 16.0),
              backgroundColor: Color.fromARGB(255, 0, 188, 207),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(width: 2.0, color: Colors.white),
              ),
              elevation: 5,
            ),
            child: Text(
              'Seleccionar Hora',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 30),
          child: Text(
            'Fecha seleccionada: ${DateFormat('dd/MM/yyyy', 'es').format(seleccionarFecha)}',
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 30),
          child: Text(
            'Hora seleccionada: ${_formatHora(hora)}',
          ),
        ),
        SizedBox(height: 20),
        Container(
  padding: EdgeInsets.only(left: 25),
  child: Row(
    children: [
      Checkbox(
        value: presencial,
        onChanged: (value) {
          setState(() {
            presencial = value!;
            remota = false; // Asegura que solo una opción esté seleccionada
          });
        },
      ),
      Text('Presencial'),
      SizedBox(width: 20),
      Checkbox(
        value: remota,
        onChanged: (value) {
          setState(() {
            remota = value!;
            presencial = false; // Asegura que solo una opción esté seleccionada
          });
        },
      ),
      Text('Remota'),
      if (remota)
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 20),
            child: TextField(
              controller: linkController,
              decoration: InputDecoration(
                hintText: 'Ingresa el link',
              ),
            ),
          ),
        ),
    ],
  ),
),
        
        SizedBox(height: 20),
        Padding(
          padding: EdgeInsets.only(left: 25, bottom: 20),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.75,
            padding: EdgeInsets.symmetric(horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: Colors.grey),
            ),
            child: TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                hintText: 'Explícame un poco tu requerimiento',
                border: InputBorder.none,
              ),
              cursorColor: Color.fromARGB(255, 0, 188, 207),
            ),
          ),
        ),
        Center(
          child: Container(
            margin: EdgeInsets.only(bottom: 15),
            width: MediaQuery.of(context).size.width * 0.4,
            child: ElevatedButton(
              onPressed: _agendarCita,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                backgroundColor: Color.fromRGBO(9, 25, 87, 1.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  side: BorderSide(width: 2.0, color: Colors.white),
                ),
                elevation: 5,
              ),
              child: Text(
                'Agendar Cita',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDatePicker() {
    return SfDateRangePicker(
      todayHighlightColor: Color.fromRGBO(0, 189, 206, 1),
      selectionColor: Color.fromRGBO(0, 189, 206, 1),
      startRangeSelectionColor: Color.fromRGBO(0, 189, 206, 1),
      selectionTextStyle: TextStyle(color: Colors.black),
      headerStyle: DateRangePickerHeaderStyle(
        textStyle: TextStyle(color: Colors.black),
      ),
      navigationDirection: DateRangePickerNavigationDirection.horizontal,
      showActionButtons: true,
      enablePastDates: false,
      selectionShape: DateRangePickerSelectionShape.circle,
      showNavigationArrow: true,
      selectableDayPredicate: (DateTime date) {
        return !coloredDates.contains(date) &&
            date.weekday != DateTime.saturday &&
            date.weekday != DateTime.sunday;
      },
      onSelectionChanged: (DateRangePickerSelectionChangedArgs args) {
        setState(() {
          seleccionarFecha = args.value;
        });
      },
      onSubmit: (_) {
        _showCustomTimePicker(context);
      },
    );
  }

  String _formatHora(TimeOfDay timeOfDay) {
    final now = DateTime.now();
    final dateTime = DateTime(now.year, now.month, now.day, timeOfDay.hour, timeOfDay.minute);
    final formattedTime = DateFormat.jm().format(dateTime);
    return formattedTime;
  }

  void _showCustomTimePicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext builder) {
        return CustomTimePicker(
          initialTime: hora,
          onTimeSelected: (TimeOfDay selectedTime) {
            setState(() {
              hora = selectedTime;
            });
            Navigator.of(context).pop();
          },
        );
      },
    );
  }
}
