import 'package:flutter/material.dart';
import 'package:googleapis/calendar/v3.dart' as calendar;
import 'package:googleapis_auth/auth_io.dart';

class Meet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Generador de enlaces de Google Meet')),
        body: Center(
          child: ElevatedButton(
            onPressed: () async {
              try {
                var meetingLink = await generateMeetingLink();
                print('Enlace de reunión generado: $meetingLink');
                // Aquí puedes manejar el enlace generado, como abrirlo en un navegador.
              } catch (e) {
                print('Error al generar el enlace de reunión: $e');
                // Manejo de errores
              }
            },
            child: Text('Generar Enlace de Reunión'),
          ),
        ),
      ),
    );
  }

  Future<String> generateMeetingLink() async {
    final _credentials = ServiceAccountCredentials.fromJson({
    "type": "service_account",
    "project_id": "mentalink",
    "private_key_id": "267b2a29fd8d4e0645b0c5a21f995f8212a8f5b3",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDiokZe64bnOaTy\n78RfmoWXxKqAe4QnAl3rZ6H2RTF/NL9Vp1kQ6FrKNDmalyvw5wZQs4w1NqoXy7h0\nua2XSN6hhfhC3p9vYBz/iNpIO894MkMrKKMSc67dricfpupBVUZQerRIS38wwLVq\nEWlx0/Uj8gqJKoe2/UJyGfrJLuHfUt6blH7OibB1lA8XJ+mLWn1+93H5CoOLXdUy\nQuhkeQ3cSfdykSvxbiVo7eUoeoDBHkmJ1RiA7EZjiXGQII2UHJvKjKEZM6EwiB7Q\nrU2AUHv3UtmK7nMi8Cu4Q6Q6ejLRQqn3jCbMTVxB3smwej9IzVPhhIBoPt3lxopI\nFNFYsMghAgMBAAECggEAAXvbVuzsV8W3GIHCM6JfnGAvge1XxBNIzvfWpeCLQ9Wy\nKKr9PeDY5/4tCrUm1r+FzqVKS6E6vl1OrRxNGxKL+0XqW50OXAHmrAlMQpD6WViy\nO2KwpKLeGCSh1sbL6FcZAYG4KJ6ulmtglLFIqIk2ekCFWfi4ZZXlZ46s0hXiPokk\nIAL635yZvdT/0DP5nDDi0fI+NH3VxI4+Tr5UD7yB4hskl9opixDUschWCvE27Dfn\n9v5NUP9TzP2L0RLXKKvUhyzzbu73zFXRlCBr3TMMGdQBhclAX44xT4OtYxEELvoo\n6dYV8yiG7aAdCKr/zey/2Ak2XKIR8gbgljjCuzIDUQKBgQDyUPh/JtcrD7eNbl6P\n56zueVB/AmH1CmJWCVzFIldn3/MaN3Ri5qiINzeGpokP5IedFhcFm51alX5IHA/m\nk7dDpJhg+UhVW/lEgCsSuqGoYWzx5g2J3wbWXkBC/EiQVPI+9eJkh+00oshVaPjL\n+5dEl1duOaGqFEJNxd2zW5JMWQKBgQDvbpexJQ2LJ941qxm1BazbJD20U9tDi0R3\nKbZ5h+Uelae8kZ6DZlQzRqzgtAFU9b+uc3vc6/v2TgK5tuRp10kI/j3eP5lST8o3\n3g6XE7G62bMuhHKj38n9xgI+128WLyUttL/P8XWIIh7ca65QGLnm2PvC+TUYUObC\nlv05KUXBCQKBgGOjL8r46ZjnSY56R5/cn5sffx36mNTthCnkh6T3zgEEcS3ih5Tz\nS3FXYxmW+Nz0F19cafMAXd+VgOudvlwNeVnzIEUfu8J9oy2rlgqJe1eFWArPkdmT\nP3h+IOZqXlwa0dFZwdGcosj19nJIS6V0umqV4HmOcQ9CbVEVf2f0y19hAoGATXZ3\nR02YkyPj5XMkzwc2BHQ2LmhO8QxWq0LokWsg+oMqkHyATzzFEw3TkqNKJwWW7UbZ\nlQEYNHjKsvDz9zY6n9k5hPUIkrPT1b1W9RPfFXenW+5n9JLLk/oC8ffbLc809ROc\nVxdkkhWP7Ho+HBXT11buJQdhYSuTbPNSm7K5qZkCgYAxpz2sdXHCcZ2EwJ5yj7sN\n/b/aGT4D/h4FV7LXhKcFpZG2wpkaq4Mi19NTtVeA4LxYxH5x6+/YHJrhumNVDLyk\np6dpGTql9dzign9nSLwShhvZSY1TwVPLyqECAqn5UfC5pT1Jty1zpBNsjOnHEFeM\nFyDE6o7ZOU/enC5KJrlLaw==\n-----END PRIVATE KEY-----\n",
    "client_email": "mentalink@mentalink.iam.gserviceaccount.com",
    "client_id": "106763373788757272360",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/mentalink%40mentalink.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  });


    final scopes = [calendar.CalendarApi.calendarScope];

    // Autenticación usando las credenciales de la cuenta de servicio
    final client = await clientViaServiceAccount(_credentials, scopes);

    // Crear una instancia de la API de Calendar
    final calendarApi = calendar.CalendarApi(client);

    // Detalles del evento para la reunión de Google Meet
    final startDateTime = DateTime.now().toUtc(); // Fecha y hora actual en UTC
    final endDateTime = startDateTime.add(Duration(hours: 1)); // Una hora después del inicio

    final event = calendar.Event()
      ..summary = 'Reunión de prueba'
      ..start = calendar.EventDateTime.fromJson({
        'dateTime': startDateTime.toUtc().toIso8601String(),
        'timeZone': 'GMT+00:00',
      })
      ..end = calendar.EventDateTime.fromJson({
        'dateTime': endDateTime.toUtc().toIso8601String(),
        'timeZone': 'GMT+00:00',
      });

    // Configurar la conferencia de Google Meet si está disponible
    if (calendarApi != null) {
      event.conferenceData = calendar.ConferenceData()
        ..createRequest = calendar.CreateConferenceRequest(
          requestId: 'unique-request-id',
          conferenceSolutionKey: calendar.ConferenceSolutionKey(
            type: 'hangoutsMeet',
          ),
        );
    }

    try {
      // Crear el evento en Google Calendar
      final createdEvent = await calendarApi.events.insert(event, 'primary');

      // Obtener el enlace de la reunión de Google Meet
      final meetingLink = createdEvent?.conferenceData?.entryPoints?[0]?.uri;
      return meetingLink ?? '';
    } catch (e) {
      print('Error al crear el evento en Google Calendar: $e');
      throw Exception('Error al crear el evento en Google Calendar');
    }
  }
}
