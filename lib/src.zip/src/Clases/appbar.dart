// ignore_for_file: camel_case_types, avoid_unnecessary_containers, prefer_const_constructors

import 'package:flutter/material.dart';

class appbar{
  
  PreferredSizeWidget? appbarPrincipal = AppBar(
    
    title: Container(

      child: Row(

        mainAxisAlignment: MainAxisAlignment.spaceAround,

        children: [

          Container(
            child: Image.network(
              "https://mentalink.tepuy21.com/assets/images/Logo_Mentalink.png",
              width: 150,
              height: 155,
            ),
          ),

          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(50),
              image: DecorationImage(
                image: AssetImage('ImagenPerfil.png'),
                fit: BoxFit.cover,
              ),
              border: Border.all(
                color: Colors.white,
                width: 2.0,
              ),
            ),
          )
        ],
      ),
    ),
    toolbarHeight: 65, // Reemplaza con la altura deseada
    backgroundColor: Color.fromRGBO(9, 25, 87, 1.0),
    foregroundColor: Colors.white
  );

  getAppbar(){

    return appbarPrincipal;
  }
}